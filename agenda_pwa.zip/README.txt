AGENDA PWA — PAQUETE PARA MÓVIL

Contenido:
- index.html       Aplicación
- manifest.json    Configuración para instalarla como app
- service-worker.js Funcionamiento offline y caché
- icon.svg         Icono de la app

INSTALACIÓN EN ANDROID
1. Sube estos archivos a un sitio web que use HTTPS.
2. Abre la dirección desde Chrome en Android.
3. Chrome debería ofrecer "Instalar aplicación" o "Añadir a pantalla de inicio".
4. Instálala. Aparecerá como una app independiente llamada "Agenda".

IMPORTANTE
Una PWA necesita servirse desde HTTPS (o localhost durante desarrollo).
Las notas se guardan en el almacenamiento local del navegador/dispositivo.
